"""Models must survive a round trip through sqlite."""

from app import store
from app.models import MODELS


def test_every_model_round_trips():
    record = {'vehicle_vin': 'x', 'customer_id': 'x', 'stage': 'x', 'sale_price': 1, 'assigned_salesperson': 'x', 'probability': 1, 'notes': 'x'}
    saved = store.save('pipeline_deal', record)
    assert saved['id'] is not None, 'no id assigned for pipeline_deal'
    fetched = store.get('pipeline_deal', saved['id'])
    assert fetched is not None, 'pipeline_deal did not persist'
    for key, value in record.items():
        assert fetched[key] == value, (key, fetched[key], value)
    assert any(r['id'] == saved['id'] for r in store.list_all('pipeline_deal'))
    record = {'vehicle_id': 'x', 'customer_id': 'x', 'salesperson_id': 'x', 'scheduled_date': 'x', 'status': 'x', 'source': 'x', 'notes': 'x'}
    saved = store.save('test_drive_booking', record)
    assert saved['id'] is not None, 'no id assigned for test_drive_booking'
    fetched = store.get('test_drive_booking', saved['id'])
    assert fetched is not None, 'test_drive_booking did not persist'
    for key, value in record.items():
        assert fetched[key] == value, (key, fetched[key], value)
    assert any(r['id'] == saved['id'] for r in store.list_all('test_drive_booking'))
    record = {'vin': 'x', 'stock_number': 'x', 'make': 'x', 'model': 'x', 'year': 1, 'mileage': 1, 'price': 1.5, 'status': 'x'}
    saved = store.save('vehicle', record)
    assert saved['id'] is not None, 'no id assigned for vehicle'
    fetched = store.get('vehicle', saved['id'])
    assert fetched is not None, 'vehicle did not persist'
    for key, value in record.items():
        assert fetched[key] == value, (key, fetched[key], value)
    assert any(r['id'] == saved['id'] for r in store.list_all('vehicle'))


def test_models_expose_their_fields():
    assert MODELS, 'no models were generated'
    for cap_id, cls in MODELS.items():
        instance = cls.from_dict({})
        assert instance.to_dict()['id'] is None
        assert cls.FIELDS, cap_id
