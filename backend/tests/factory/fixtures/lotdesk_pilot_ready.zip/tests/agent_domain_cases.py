"""Additional domain cases proposed by the coding agent under TESTER.

These are mutations of spec-derived payloads. They cannot replace the
kernel suite in test_routes.py / test_models.py. The file is named
agent_domain_cases.py (no test_ prefix) so pytest does not collect it
into the gated suite.
"""

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_agent_domain_cases():
    failures = []
    payload_0 = {'make': 'sample', 'mileage': 0, 'model': 'sample', 'price': 0.0, 'status': 'available', 'stock_number': 'sample', 'vin': 'sample', 'year': 1899}
    resp_0 = client.post("/v1/vehicle_inventory", json=payload_0)
    if resp_0.status_code == 200 and resp_0.json().get('ok') is not False:
        failures.append('year below allowed minimum' or 'case 0 should have been rejected')
    payload_1 = {'make': 'Ford', 'mileage': 120000, 'model': 'F-150', 'price': 18995.0, 'status': 'available', 'stock_number': 'A1299', 'vin': '1FTFW1EF7EKG12345', 'year': 2014}
    resp_1 = client.post("/v1/vehicle_inventory", json=payload_1)
    if resp_1.status_code != 200 or resp_1.json().get('ok') is False:
        failures.append('valid used-car values' or 'case 1 should have been accepted')
    payload_2 = {'customer_id': 'cust-441', 'notes': 'Customer prefers afternoon', 'salesperson_id': 'sales-09', 'scheduled_date': '2025-10-20T15:00:00Z', 'source': 'customer', 'status': 'requested', 'vehicle_id': 'veh-882'}
    resp_2 = client.post("/v1/test_drive_bookings", json=payload_2)
    if resp_2.status_code != 200 or resp_2.json().get('ok') is False:
        failures.append('valid booking payload' or 'case 2 should have been accepted')
    payload_3 = {'assigned_salesperson': 'sample', 'customer_id': 'sample', 'notes': 'sample', 'probability': 150, 'sale_price': 0, 'stage': 'new', 'vehicle_vin': 'sample'}
    resp_3 = client.post("/v1/sales_pipeline_board", json=payload_3)
    if resp_3.status_code == 200 and resp_3.json().get('ok') is not False:
        failures.append('probability must be 0-100' or 'case 3 should have been rejected')
    payload_4 = {'assigned_salesperson': 'sales-09', 'customer_id': 'cust-441', 'notes': 'Strong trade-in', 'probability': 75, 'sale_price': 22000, 'stage': 'new', 'vehicle_vin': '1FTFW1EF7EKG12345'}
    resp_4 = client.post("/v1/sales_pipeline_board", json=payload_4)
    if resp_4.status_code != 200 or resp_4.json().get('ok') is False:
        failures.append('valid opportunity values' or 'case 4 should have been accepted')
    assert not failures, '; '.join(failures)

