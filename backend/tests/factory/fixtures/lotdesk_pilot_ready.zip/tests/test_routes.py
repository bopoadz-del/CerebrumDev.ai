"""The HTTP surface answers, and what it answers has the right shape."""

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_kernel_jobs_roster():
    """GET /v1/jobs publishes every kernel JD; distinctive routes answer."""
    resp = client.get("/v1/jobs")
    assert resp.status_code == 200
    jobs = resp.json()["jobs"]
    by_kernel = {j["kernel"]: j for j in jobs}
    assert set(by_kernel) == {
        "COLLECTOR", "CLONER", "WRITER", "TESTER", "STORE_MANAGER"
    }
    assert by_kernel["COLLECTOR"]["title"] == "Binding surveyor"
    assert by_kernel["CLONER"]["title"] == "Block stocker"
    assert by_kernel["WRITER"]["title"] == "Platform manufacturer"
    assert by_kernel["TESTER"]["title"] == "Acceptance inspector"
    assert by_kernel["STORE_MANAGER"]["title"] == "Store registrar"
    for job in jobs:
        assert job["mandate"] and job["http_routes"] and job["agent"]
    catalog = client.get("/v1/catalog")
    assert catalog.status_code == 200
    assert catalog.json()["kernel"] == "COLLECTOR"
    inventory = client.get("/v1/inventory")
    assert inventory.status_code == 200
    assert inventory.json()["kernel"] == "CLONER"
    assert "lock" in inventory.json()
    caps_resp = client.get("/v1/capabilities")
    assert caps_resp.status_code == 200
    assert isinstance(caps_resp.json()["items"], list)
    gates = client.get("/v1/gates")
    assert gates.status_code == 200
    assert gates.json()["kernel"] == "TESTER"
    assert gates.json()["runs_over_http"] is False
    prov = client.get("/v1/provenance")
    assert prov.status_code == 200
    assert prov.json()["kernel"] == "STORE_MANAGER"


def test_every_capability_route_answers():
    """Code-phase: each capability POST answers HTTP 200 JSON.
    Store ok: False is allowed here — acceptance is the pilot test."""
    failures = []
    payload = {'vin': 'sample', 'stock_number': 'sample', 'make': 'sample', 'model': 'sample', 'year': 1900, 'mileage': 0, 'price': 0.0, 'status': 'available'}
    resp = client.post("/v1/vehicle_inventory", json=payload)
    if resp.status_code != 200:
        failures.append('vehicle_inventory: HTTP ' + str(resp.status_code) + ': ' + resp.text[:200])
    else:
        try:
            body = resp.json()
        except Exception:
            failures.append('vehicle_inventory: response is not JSON')
        else:
            if not isinstance(body, dict):
                failures.append('vehicle_inventory: JSON body is not a dict')
            listed = client.get("/v1/vehicle_inventory")
            if listed.status_code != 200:
                failures.append('vehicle_inventory list: HTTP ' + str(listed.status_code))

    payload = {'vehicle_id': 'sample', 'customer_id': 'sample', 'salesperson_id': 'sample', 'scheduled_date': 'sample', 'status': 'requested', 'source': 'customer', 'notes': 'sample'}
    resp = client.post("/v1/test_drive_bookings", json=payload)
    if resp.status_code != 200:
        failures.append('test_drive_bookings: HTTP ' + str(resp.status_code) + ': ' + resp.text[:200])
    else:
        try:
            body = resp.json()
        except Exception:
            failures.append('test_drive_bookings: response is not JSON')
        else:
            if not isinstance(body, dict):
                failures.append('test_drive_bookings: JSON body is not a dict')
            listed = client.get("/v1/test_drive_bookings")
            if listed.status_code != 200:
                failures.append('test_drive_bookings list: HTTP ' + str(listed.status_code))

    payload = {'vehicle_vin': 'sample', 'customer_id': 'sample', 'stage': 'new', 'sale_price': 0, 'assigned_salesperson': 'sample', 'probability': 0, 'notes': 'sample'}
    resp = client.post("/v1/sales_pipeline_board", json=payload)
    if resp.status_code != 200:
        failures.append('sales_pipeline_board: HTTP ' + str(resp.status_code) + ': ' + resp.text[:200])
    else:
        try:
            body = resp.json()
        except Exception:
            failures.append('sales_pipeline_board: response is not JSON')
        else:
            if not isinstance(body, dict):
                failures.append('sales_pipeline_board: JSON body is not a dict')
            listed = client.get("/v1/sales_pipeline_board")
            if listed.status_code != 200:
                failures.append('sales_pipeline_board list: HTTP ' + str(listed.status_code))

    assert not failures, "; ".join(failures)


@pytest.mark.pilot
def test_every_capability_route_accepts_payload():
    """Pilot: spec payload is accepted (ok is not False) and persisted.
    Not the factory code-phase gate."""
    failures = []
    payload = {'vin': 'sample', 'stock_number': 'sample', 'make': 'sample', 'model': 'sample', 'year': 1900, 'mileage': 0, 'price': 0.0, 'status': 'available'}
    resp = client.post("/v1/vehicle_inventory", json=payload)
    if resp.status_code != 200:
        failures.append('vehicle_inventory: HTTP ' + str(resp.status_code) + ': ' + resp.text[:200])
    elif resp.json().get("ok") is False:
        failures.append('vehicle_inventory rejected a payload built from its own schema: ' + str(resp.json().get('error')))
    else:
        listed = client.get("/v1/vehicle_inventory")
        if listed.status_code != 200:
            failures.append('vehicle_inventory list: HTTP ' + str(listed.status_code))
        elif not listed.json()["items"]:
            failures.append('vehicle_inventory accepted a record but persisted nothing')
        else:
            item_id = listed.json()["items"][0]["id"]
            got = client.get(f"/v1/vehicle_inventory/{item_id}")
            if got.status_code != 200:
                failures.append('vehicle_inventory get: HTTP ' + str(got.status_code))
            missing = client.get("/v1/vehicle_inventory/999999")
            if missing.status_code != 404:
                failures.append('vehicle_inventory missing id: HTTP ' + str(missing.status_code) + ' (expected 404)')

    payload = {'vehicle_id': 'sample', 'customer_id': 'sample', 'salesperson_id': 'sample', 'scheduled_date': 'sample', 'status': 'requested', 'source': 'customer', 'notes': 'sample'}
    resp = client.post("/v1/test_drive_bookings", json=payload)
    if resp.status_code != 200:
        failures.append('test_drive_bookings: HTTP ' + str(resp.status_code) + ': ' + resp.text[:200])
    elif resp.json().get("ok") is False:
        failures.append('test_drive_bookings rejected a payload built from its own schema: ' + str(resp.json().get('error')))
    else:
        listed = client.get("/v1/test_drive_bookings")
        if listed.status_code != 200:
            failures.append('test_drive_bookings list: HTTP ' + str(listed.status_code))
        elif not listed.json()["items"]:
            failures.append('test_drive_bookings accepted a record but persisted nothing')
        else:
            item_id = listed.json()["items"][0]["id"]
            got = client.get(f"/v1/test_drive_bookings/{item_id}")
            if got.status_code != 200:
                failures.append('test_drive_bookings get: HTTP ' + str(got.status_code))
            missing = client.get("/v1/test_drive_bookings/999999")
            if missing.status_code != 404:
                failures.append('test_drive_bookings missing id: HTTP ' + str(missing.status_code) + ' (expected 404)')

    payload = {'vehicle_vin': 'sample', 'customer_id': 'sample', 'stage': 'new', 'sale_price': 0, 'assigned_salesperson': 'sample', 'probability': 0, 'notes': 'sample'}
    resp = client.post("/v1/sales_pipeline_board", json=payload)
    if resp.status_code != 200:
        failures.append('sales_pipeline_board: HTTP ' + str(resp.status_code) + ': ' + resp.text[:200])
    elif resp.json().get("ok") is False:
        failures.append('sales_pipeline_board rejected a payload built from its own schema: ' + str(resp.json().get('error')))
    else:
        listed = client.get("/v1/sales_pipeline_board")
        if listed.status_code != 200:
            failures.append('sales_pipeline_board list: HTTP ' + str(listed.status_code))
        elif not listed.json()["items"]:
            failures.append('sales_pipeline_board accepted a record but persisted nothing')
        else:
            item_id = listed.json()["items"][0]["id"]
            got = client.get(f"/v1/sales_pipeline_board/{item_id}")
            if got.status_code != 200:
                failures.append('sales_pipeline_board get: HTTP ' + str(got.status_code))
            missing = client.get("/v1/sales_pipeline_board/999999")
            if missing.status_code != 404:
                failures.append('sales_pipeline_board missing id: HTTP ' + str(missing.status_code) + ' (expected 404)')

    assert not failures, "; ".join(failures)
