"""The platform runs, and it runs without the store."""

import os

import pytest


def test_capabilities_import():
    from app.actions import vehicle_inventory
    assert vehicle_inventory.CAPABILITY_ID
    from app.actions import test_drive_bookings
    assert test_drive_bookings.CAPABILITY_ID
    from app.actions import sales_pipeline_board
    assert sales_pipeline_board.CAPABILITY_ID


def test_dispatch_runs_offline():
    """No store env, no network: every block must LOAD and EXECUTE from
    vendor/. A block-level refusal of this bare probe is still local
    execution; an import failure is the store dependency this test
    exists to catch."""
    for var in ("CEREBRUM_API_URL", "CEREBRUM_API_KEY", "CEREBRUM_API_TOKEN"):
        os.environ.pop(var, None)
    from app.dispatch import execute, load_block
    for block_id in ['analytics', 'capture', 'dashboard', 'database', 'estate_registry', 'notification', 'queue', 'storage', 'team', 'workflow']:
        load_block(block_id)
    actions = {'analytics': 'track_event', 'dashboard': 'render', 'database': 'query', 'notification': 'send', 'queue': 'enqueue', 'storage': 'store', 'team': 'create_team', 'workflow': 'run'}
    for block_id in ['analytics', 'capture', 'dashboard', 'database', 'estate_registry', 'notification', 'queue', 'storage', 'team', 'workflow']:
        try:
            result = execute(block_id, {}, action=actions.get(block_id))
        except RuntimeError as exc:
            # The block ran and refused the empty probe -- fine here;
            # the pilot test below demands Store-backed success.
            # An import error is never fine.
            assert "No module named" not in str(exc), (block_id, exc)
            assert "cannot import" not in str(exc), (block_id, exc)
        else:
            assert isinstance(result, dict), block_id


def test_kit_packs_present():
    """The download is a product tree: kits/ next to vendor/blocks."""
    from pathlib import Path as _Path
    kits = _Path(__file__).resolve().parents[1] / "kits"
    assert kits.is_dir(), "kits/ missing from the delivered platform"
    assert list(kits.glob("*/manifest.json")), "no kit pack manifests"


def test_every_capability_handle_returns_mapping():
    """Code-phase: the coder wired handle() and it returns a dict.
    Store ok: False or a Store exception is not this gate."""
    for var in ("CEREBRUM_API_URL", "CEREBRUM_API_KEY"):
        os.environ.pop(var, None)
    failures = []
    from app.actions import vehicle_inventory
    try:
        out = vehicle_inventory.handle({'vin': 'sample', 'stock_number': 'sample', 'make': 'sample', 'model': 'sample', 'year': 1900, 'mileage': 0, 'price': 0.0, 'status': 'available'})
    except Exception as exc:
        out = {'ok': False, 'error': type(exc).__name__ + ': ' + str(exc)}
    if not isinstance(out, dict):
        failures.append('vehicle_inventory handle() must return a dict, got ' + type(out).__name__)
    from app.actions import test_drive_bookings
    try:
        out = test_drive_bookings.handle({'vehicle_id': 'sample', 'customer_id': 'sample', 'salesperson_id': 'sample', 'scheduled_date': 'sample', 'status': 'requested', 'source': 'customer', 'notes': 'sample'})
    except Exception as exc:
        out = {'ok': False, 'error': type(exc).__name__ + ': ' + str(exc)}
    if not isinstance(out, dict):
        failures.append('test_drive_bookings handle() must return a dict, got ' + type(out).__name__)
    from app.actions import sales_pipeline_board
    try:
        out = sales_pipeline_board.handle({'vehicle_vin': 'sample', 'customer_id': 'sample', 'stage': 'new', 'sale_price': 0, 'assigned_salesperson': 'sample', 'probability': 0, 'notes': 'sample'})
    except Exception as exc:
        out = {'ok': False, 'error': type(exc).__name__ + ': ' + str(exc)}
    if not isinstance(out, dict):
        failures.append('sales_pipeline_board handle() must return a dict, got ' + type(out).__name__)
    assert not failures, "; ".join(failures)


@pytest.mark.pilot
def test_every_capability_executes_end_to_end():
    """Pilot: each handler runs its blocks on a spec payload and
    Store must accept it. Not the factory code-phase gate."""
    for var in ("CEREBRUM_API_URL", "CEREBRUM_API_KEY"):
        os.environ.pop(var, None)
    import json as _json
    failures = []
    from app.actions import vehicle_inventory
    out = vehicle_inventory.handle({'vin': 'sample', 'stock_number': 'sample', 'make': 'sample', 'model': 'sample', 'year': 1900, 'mileage': 0, 'price': 0.0, 'status': 'available'})
    if not isinstance(out, dict):
        failures.append('vehicle_inventory returned a non-dict: ' + repr(out)[:120])
    elif out.get("ok") is False:
        failures.append('vehicle_inventory rejected a payload built from its own schema: ' + str(out.get('error')))
    elif '\"status\": \"error\"' in _json.dumps(out) or '\"status\": \"failed\"' in _json.dumps(out):
        failures.append('vehicle_inventory reported ok around a failed block call: ' + _json.dumps(out)[:300])
    from app.actions import test_drive_bookings
    out = test_drive_bookings.handle({'vehicle_id': 'sample', 'customer_id': 'sample', 'salesperson_id': 'sample', 'scheduled_date': 'sample', 'status': 'requested', 'source': 'customer', 'notes': 'sample'})
    if not isinstance(out, dict):
        failures.append('test_drive_bookings returned a non-dict: ' + repr(out)[:120])
    elif out.get("ok") is False:
        failures.append('test_drive_bookings rejected a payload built from its own schema: ' + str(out.get('error')))
    elif '\"status\": \"error\"' in _json.dumps(out) or '\"status\": \"failed\"' in _json.dumps(out):
        failures.append('test_drive_bookings reported ok around a failed block call: ' + _json.dumps(out)[:300])
    from app.actions import sales_pipeline_board
    out = sales_pipeline_board.handle({'vehicle_vin': 'sample', 'customer_id': 'sample', 'stage': 'new', 'sale_price': 0, 'assigned_salesperson': 'sample', 'probability': 0, 'notes': 'sample'})
    if not isinstance(out, dict):
        failures.append('sales_pipeline_board returned a non-dict: ' + repr(out)[:120])
    elif out.get("ok") is False:
        failures.append('sales_pipeline_board rejected a payload built from its own schema: ' + str(out.get('error')))
    elif '\"status\": \"error\"' in _json.dumps(out) or '\"status\": \"failed\"' in _json.dumps(out):
        failures.append('sales_pipeline_board reported ok around a failed block call: ' + _json.dumps(out)[:300])
    assert not failures, "; ".join(failures)
