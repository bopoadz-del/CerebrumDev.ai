"""SQLite persistence for the domain models.

stdlib sqlite3 and a local file: the platform stores data with no
database server and no network. STORAGE_PATH relocates the file.
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any, Dict, List

SCHEMA = {
    "pipeline_deal": "CREATE TABLE IF NOT EXISTS pipeline_deal (id INTEGER PRIMARY KEY AUTOINCREMENT, vehicle_vin TEXT, customer_id TEXT, stage TEXT, sale_price INTEGER, assigned_salesperson TEXT, probability INTEGER, notes TEXT)",
    "test_drive_booking": "CREATE TABLE IF NOT EXISTS test_drive_booking (id INTEGER PRIMARY KEY AUTOINCREMENT, vehicle_id TEXT, customer_id TEXT, salesperson_id TEXT, scheduled_date TEXT, status TEXT, source TEXT, notes TEXT)",
    "vehicle": "CREATE TABLE IF NOT EXISTS vehicle (id INTEGER PRIMARY KEY AUTOINCREMENT, vin TEXT, stock_number TEXT, make TEXT, model TEXT, year INTEGER, mileage INTEGER, price REAL, status TEXT)",
}

COLUMNS: Dict[str, List[str]] = {'vehicle': ['vin', 'stock_number', 'make', 'model', 'year', 'mileage', 'price', 'status'], 'test_drive_booking': ['vehicle_id', 'customer_id', 'salesperson_id', 'scheduled_date', 'status', 'source', 'notes'], 'pipeline_deal': ['vehicle_vin', 'customer_id', 'stage', 'sale_price', 'assigned_salesperson', 'probability', 'notes']}


def db_path() -> Path:
    root = Path(os.getenv("STORAGE_PATH", "./data"))
    root.mkdir(parents=True, exist_ok=True)
    return root / "platform.db"


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    for ddl in SCHEMA.values():
        conn.execute(ddl)
    conn.commit()
    return conn


def save(entity: str, record: Dict[str, Any]) -> Dict[str, Any]:
    """Insert a record and return it with its assigned id."""
    cols = COLUMNS[entity]
    values = [record.get(c) for c in cols]
    placeholders = ", ".join("?" for _ in cols)
    conn = connect()
    try:
        cur = conn.execute(
            f"INSERT INTO {entity} ({', '.join(cols)}) VALUES ({placeholders})",
            values,
        )
        conn.commit()
        return {"id": cur.lastrowid, **{c: record.get(c) for c in cols}}
    finally:
        conn.close()


def list_all(entity: str) -> List[Dict[str, Any]]:
    conn = connect()
    try:
        rows = conn.execute(f"SELECT * FROM {entity} ORDER BY id").fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get(entity: str, record_id: int) -> Dict[str, Any] | None:
    conn = connect()
    try:
        row = conn.execute(
            f"SELECT * FROM {entity} WHERE id = ?", (record_id,)
        ).fetchone()
        return dict(row) if row else None
    finally:
        conn.close()
