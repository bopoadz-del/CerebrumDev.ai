"""Domain models for this platform.

Plain dataclasses on purpose: the delivered platform must run with no
ORM, no service, and no network. Persistence is in app/store.py.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, Optional


@dataclass
class PipelineDeal:
    """Entity for capability sales_pipeline_board."""

    id: Optional[int] = None
    vehicle_vin: str = ""
    customer_id: str = ""
    stage: str = 'new'
    sale_price: int = 0
    assigned_salesperson: str = ""
    probability: int = 0
    notes: str = ""

    FIELDS = ['vehicle_vin', 'customer_id', 'stage', 'sale_price', 'assigned_salesperson', 'probability', 'notes']
    CONSTRAINTS = {'stage': {'allowed_values': ['new', 'contacted', 'test_drive', 'offer', 'sold', 'lost']}, 'sale_price': {'min': 0}, 'probability': {'min': 0, 'max': 100}}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PipelineDeal":
        known = {k: v for k, v in (data or {}).items() if k in cls.FIELDS}
        return cls(id=(data or {}).get("id"), **known)


@dataclass
class TestDriveBooking:
    """Entity for capability test_drive_bookings."""

    id: Optional[int] = None
    vehicle_id: str = ""
    customer_id: str = ""
    salesperson_id: str = ""
    scheduled_date: str = ""
    status: str = 'requested'
    source: str = 'customer'
    notes: str = ""

    FIELDS = ['vehicle_id', 'customer_id', 'salesperson_id', 'scheduled_date', 'status', 'source', 'notes']
    CONSTRAINTS = {'status': {'allowed_values': ['requested', 'confirmed', 'completed', 'cancelled', 'no_show']}, 'source': {'allowed_values': ['customer', 'dealer']}}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TestDriveBooking":
        known = {k: v for k, v in (data or {}).items() if k in cls.FIELDS}
        return cls(id=(data or {}).get("id"), **known)


@dataclass
class Vehicle:
    """Entity for capability vehicle_inventory."""

    id: Optional[int] = None
    vin: str = ""
    stock_number: str = ""
    make: str = ""
    model: str = ""
    year: int = 1900
    mileage: int = 0
    price: float = 0.0
    status: str = 'available'

    FIELDS = ['vin', 'stock_number', 'make', 'model', 'year', 'mileage', 'price', 'status']
    CONSTRAINTS = {'year': {'min': 1900, 'max': 2100}, 'mileage': {'min': 0, 'max': 10000000}, 'price': {'min': 0.0}, 'status': {'allowed_values': ['available', 'pending', 'sold', 'wholesale']}}

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Vehicle":
        known = {k: v for k, v in (data or {}).items() if k in cls.FIELDS}
        return cls(id=(data or {}).get("id"), **known)


MODELS = {
    "sales_pipeline_board": PipelineDeal,
    "test_drive_bookings": TestDriveBooking,
    "vehicle_inventory": Vehicle,
}
