"""Handler for capability sales_pipeline_board.

Written by the factory WRITER role (coder LLM (kimi-k2.7-code)). Blocks are invoked through the
local dispatch runtime -- this module makes no network call.
"""

from __future__ import annotations

from typing import Any, Dict

from app.dispatch import execute

CAPABILITY_ID = "sales_pipeline_board"
BLOCK_IDS = ['dashboard', 'workflow', 'analytics', 'team']
#: Each block's declared default action (from its block.json). Blocks are
#: action-dispatched; calling one with no action is answered with an error.
BLOCK_DEFAULT_ACTIONS = {'dashboard': 'render', 'workflow': 'run', 'analytics': 'track_event', 'team': 'create_team'}


def handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    if not all(key in payload for key in ["vehicle_vin", "customer_id", "stage", "sale_price", "assigned_salesperson", "probability"]):
        return {"ok": False, "error": "Missing required fields"}

    if payload["stage"] not in ["new", "contacted", "test_drive", "offer", "sold", "lost"]:
        return {"ok": False, "error": "Invalid stage"}

    if payload["sale_price"] < 0:
        return {"ok": False, "error": "Sale price must be non-negative"}

    if payload["probability"] < 0 or payload["probability"] > 100:
        return {"ok": False, "error": "Probability must be between 0 and 100"}

    dashboard_result = execute("dashboard", {"input": payload})
    workflow_result = execute("workflow", {"input": payload, "steps": [{"block": "dashboard", "action": "render"}]})
    analytics_result = execute("analytics", {"input": payload, "action": "track_event"})

    if dashboard_result.get("status") == "error" or workflow_result.get("status") == "error" or analytics_result.get("status") == "error":
        return {"ok": False, "error": dashboard_result.get("error") or workflow_result.get("error") or analytics_result.get("error")}

    return {"ok": True, "capability": "sales_pipeline_board", "dashboard": dashboard_result, "workflow": workflow_result, "analytics": analytics_result}
