"""Capability handlers."""

from app.actions import vehicle_inventory  # noqa: F401
from app.actions import test_drive_bookings  # noqa: F401
from app.actions import sales_pipeline_board  # noqa: F401
