"""Handler for capability test_drive_bookings.

Written by the factory WRITER role (coder LLM (kimi-k2.7-code)). Blocks are invoked through the
local dispatch runtime -- this module makes no network call.
"""

from __future__ import annotations

from typing import Any, Dict

from app.dispatch import execute

CAPABILITY_ID = "test_drive_bookings"
BLOCK_IDS = ['queue', 'workflow', 'notification']
#: Each block's declared default action (from its block.json). Blocks are
#: action-dispatched; calling one with no action is answered with an error.
BLOCK_DEFAULT_ACTIONS = {'queue': 'enqueue', 'workflow': 'run', 'notification': 'send'}


def handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    vehicle_id = payload.get("vehicle_id")
    customer_id = payload.get("customer_id")
    salesperson_id = payload.get("salesperson_id")
    scheduled_date = payload.get("scheduled_date")
    status = payload.get("status")
    source = payload.get("source")
    notes = payload.get("notes")

    if not isinstance(vehicle_id, str) or not vehicle_id:
        return {"ok": False, "error": "vehicle_id is required and must be a non-empty string", "capability": CAPABILITY_ID}
    if not isinstance(customer_id, str) or not customer_id:
        return {"ok": False, "error": "customer_id is required and must be a non-empty string", "capability": CAPABILITY_ID}
    if not isinstance(scheduled_date, str) or not scheduled_date:
        return {"ok": False, "error": "scheduled_date is required and must be a non-empty string", "capability": CAPABILITY_ID}
    if status not in {"requested", "confirmed", "completed", "cancelled", "no_show"}:
        return {"ok": False, "error": "status must be one of: requested, confirmed, completed, cancelled, no_show", "capability": CAPABILITY_ID}
    if source not in {"customer", "dealer"}:
        return {"ok": False, "error": "source must be one of: customer, dealer", "capability": CAPABILITY_ID}
    if salesperson_id is not None and not isinstance(salesperson_id, str):
        return {"ok": False, "error": "salesperson_id must be a string when provided", "capability": CAPABILITY_ID}
    if notes is not None and not isinstance(notes, str):
        return {"ok": False, "error": "notes must be a string when provided", "capability": CAPABILITY_ID}

    booking = {
        "vehicle_id": vehicle_id,
        "customer_id": customer_id,
        "salesperson_id": salesperson_id,
        "scheduled_date": scheduled_date,
        "status": status,
        "source": source,
        "notes": notes,
    }

    queue_payload = {
        "queue": "test_drive_bookings",
        "job_type": "test_drive_booking",
        "payload": booking,
        "priority": 1,
    }
    queue_result = execute("queue", queue_payload, action="enqueue")
    if queue_result.get("status") == "error" or queue_result.get("error"):
        return {"ok": False, "error": queue_result.get("error") or "queue enqueue failed", "capability": CAPABILITY_ID}

    message = f"Test drive booking for vehicle {vehicle_id} on {scheduled_date} is {status}"

    workflow_steps = [
        {
            "id": "queue",
            "block": "queue",
            "action": "enqueue",
            "params": {
                "queue": "test_drive_bookings",
                "job_type": "test_drive_booking",
                "payload": booking,
            },
        },
        {
            "id": "notification",
            "block": "notification",
            "action": "send",
            "params": {
                "channel": "mcp",
                "message": message,
                "block": "queue",
            },
        },
    ]
    workflow_payload = {
        "steps": workflow_steps,
        "input": booking,
    }
    workflow_result = execute("workflow", workflow_payload, action="run")
    if workflow_result.get("status") == "error" or workflow_result.get("error"):
        return {"ok": False, "error": workflow_result.get("error") or "workflow run failed", "capability": CAPABILITY_ID}

    notification_payload = {
        "channel": "mcp",
        "message": message,
        "block": "queue",
    }
    notification_result = execute("notification", notification_payload, action="send")
    if notification_result.get("status") == "error" or notification_result.get("error"):
        return {"ok": False, "error": notification_result.get("error") or "notification send failed", "capability": CAPABILITY_ID}

    return {
        "ok": True,
        "capability": CAPABILITY_ID,
        "booking": booking,
        "queue": queue_result,
        "workflow": workflow_result,
        "notification": notification_result,
    }
