"""Handler for capability vehicle_inventory.

Written by the factory WRITER role (coder LLM (kimi-k2.7-code)). Blocks are invoked through the
local dispatch runtime -- this module makes no network call.
"""

from __future__ import annotations

from typing import Any, Dict

from app.dispatch import execute

CAPABILITY_ID = "vehicle_inventory"
BLOCK_IDS = ['estate_registry', 'database', 'storage', 'capture']
#: Each block's declared default action (from its block.json). Blocks are
#: action-dispatched; calling one with no action is answered with an error.
BLOCK_DEFAULT_ACTIONS = {'database': 'query', 'storage': 'store'}


def handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    vehicle = payload if isinstance(payload, dict) else None
    if vehicle is None:
        return {"capability": CAPABILITY_ID, "ok": False, "error": "payload must be a dict"}
    required = {
        "vin": str,
        "stock_number": str,
        "make": str,
        "model": str,
        "year": int,
        "mileage": int,
        "price": (int, float),
        "status": str,
    }
    missing = [k for k in required if k not in vehicle]
    if missing:
        return {"capability": CAPABILITY_ID, "ok": False, "error": f"missing fields: {', '.join(missing)}"}
    for key, typ in required.items():
        value = vehicle[key]
        if not isinstance(value, typ) or isinstance(value, bool):
            return {"capability": CAPABILITY_ID, "ok": False, "error": f"{key} must be {typ.__name__ if isinstance(typ, type) else 'numeric'}"}
        if key in ("vin", "stock_number", "make", "model") and not str(value).strip():
            return {"capability": CAPABILITY_ID, "ok": False, "error": f"{key} must be a non-empty string"}
    if not (1900 <= vehicle["year"] <= 2100):
        return {"capability": CAPABILITY_ID, "ok": False, "error": "year must be between 1900 and 2100"}
    if not (0 <= vehicle["mileage"] <= 10000000):
        return {"capability": CAPABILITY_ID, "ok": False, "error": "mileage must be between 0 and 10000000"}
    if vehicle["price"] < 0:
        return {"capability": CAPABILITY_ID, "ok": False, "error": "price must be >= 0"}
    if vehicle["status"] not in ("available", "pending", "sold", "wholesale"):
        return {"capability": CAPABILITY_ID, "ok": False, "error": "status must be one of available, pending, sold, wholesale"}
    record = {
        "vin": vehicle["vin"],
        "stock_number": vehicle["stock_number"],
        "make": vehicle["make"],
        "model": vehicle["model"],
        "year": vehicle["year"],
        "mileage": vehicle["mileage"],
        "price": vehicle["price"],
        "status": vehicle["status"],
    }
    estate_action = BLOCK_DEFAULT_ACTIONS.get("estate_registry")
    estate_result = execute("estate_registry", {"input": record}, action=estate_action)
    if estate_result.get("status") == "error" or "error" in estate_result:
        return {"capability": CAPABILITY_ID, "ok": False, "error": estate_result.get("error", "estate_registry failed")}
    db_result = execute("database", {"action": "insert", "table": "vehicle_inventory", "values": record})
    if db_result.get("status") == "error" or "error" in db_result:
        return {"capability": CAPABILITY_ID, "ok": False, "error": db_result.get("error", "database insert failed")}
    filename = f"{record['stock_number']}_{record['vin']}.json"
    store_result = execute("storage", {"action": "store", "filename": filename, "content": record, "metadata": {"capability": CAPABILITY_ID, "vin": record["vin"]}})
    if store_result.get("status") == "error" or "error" in store_result:
        return {"capability": CAPABILITY_ID, "ok": False, "error": store_result.get("error", "storage store failed")}
    return {
        "capability": CAPABILITY_ID,
        "ok": True,
        "vehicle": record,
        "registrations": {
            "estate_registry": estate_result,
            "database": db_result,
            "storage": store_result,
        },
    }
