"""Generated platform."""
