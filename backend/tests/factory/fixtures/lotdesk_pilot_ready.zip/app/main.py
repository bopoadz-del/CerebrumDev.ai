"""Entrypoint for the generated platform.

Runs standalone: uvicorn app.main:app. No factory, no block store, no
outbound dependency at runtime. Kernel jobs are at GET /v1/jobs.
"""

from __future__ import annotations

from fastapi import FastAPI

from app.routes import router

app = FastAPI(title="LotDesk")
app.include_router(router, prefix="/v1")


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}
