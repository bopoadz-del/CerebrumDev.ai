"""Kernel job descriptions shipped with this platform.

Frozen at manufacture time from Factory RoleContract. HTTP routes
publish each kernel's job; they never re-run that job. Inventory and
provenance read lock/provenance files live so the register stays true
to the checkout.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

JOBS = [{'kernel': 'COLLECTOR', 'title': 'Binding surveyor', 'mandate': "Resolve each capability's declared block ids into harvestable contracts. Name every capability with no block as an explicit gap so the WRITER authors that logic — never drop it from the plan. Consult the coding agent for a report-only endorse/mismatch review of each binding. Do not invent block ids, do not mutate the plan, and write nothing.", 'agent': 'consult', 'http_routes': ['GET /v1/catalog'], 'gate': 'every referenced block id is dual-registered; gaps enumerated', 'read_only': True}, {'kernel': 'CLONER', 'title': 'Block stocker', 'mandate': "Vendor each resolved block's source at a pinned commit, plus the local dispatch runtime those shims stand on, plus the kit packs the Factory shelf assigns those blocks to, so handlers import blocks instead of calling the store over HTTP. Write only vendor/**, kits/**, and blocks.lock.json. Exact answers — no agent.", 'agent': 'none', 'http_routes': ['GET /v1/inventory'], 'gate': 'every vendored block imports with no network configured', 'read_only': False}, {'kernel': 'WRITER', 'title': 'Platform manufacturer', 'mandate': "Manufacture the platform over the vendored stock: capability handlers, domain models, persistence, the HTTP surface (including each kernel's job routes), UI wiring, and GENERATE logic for the gaps the collector reported. The coding agent writes those artifacts inside WRITER lanes. Do not touch tests/ or vendor/.", 'agent': 'manufacture', 'http_routes': ['GET /v1/capabilities', 'POST /v1/{capability}', 'GET /v1/{capability}', 'GET /v1/{capability}/{id}'], 'gate': 'workspace imports and type-checks clean', 'read_only': False}, {'kernel': 'TESTER', 'title': 'Acceptance inspector', 'mandate': 'Write and run the code-phase suite against what the WRITER produced (imports, dispatch load, models, routes answer JSON, handle() returns a mapping) and bounce those failures for another writer pass. Store-backed execute-all is pilot coverage, not this gate. Consult the coding agent for extra domain cases; admit them only as mutations of spec-derived payloads. Never patch app/. Never run the suite over HTTP — GET /v1/gates describes coverage only.', 'agent': 'consult', 'http_routes': ['GET /v1/gates'], 'gate': "code-phase suite green (pytest -m 'not pilot')", 'read_only': False}, {'kernel': 'STORE_MANAGER', 'title': 'Store registrar', 'mandate': "Keep the store's books: register what this platform cloned and at which commit. This minimal form records the clone register and applies no store op. Harvesting improvements back upstream and admitting client-driven net-new capability remain unbuilt. Exact answers — no agent.", 'agent': 'none', 'http_routes': ['GET /v1/provenance'], 'gate': 'store_manager.assert_store_op_allowed passes for every op applied', 'read_only': False}]
CATALOG = {'kernel': 'COLLECTOR', 'title': 'Binding surveyor', 'mandate': "Resolve each capability's declared block ids into harvestable contracts. Name every capability with no block as an explicit gap so the WRITER authors that logic — never drop it from the plan. Consult the coding agent for a report-only endorse/mismatch review of each binding. Do not invent block ids, do not mutate the plan, and write nothing.", 'agent': 'consult', 'resolved_blocks': ['estate_registry', 'database', 'storage', 'capture', 'queue', 'workflow', 'notification', 'dashboard', 'analytics', 'team'], 'gaps': [], 'bindings': [{'capability_id': 'vehicle_inventory', 'block_ids': ['estate_registry', 'database', 'storage', 'capture'], 'gap': False}, {'capability_id': 'test_drive_bookings', 'block_ids': ['queue', 'workflow', 'notification'], 'gap': False}, {'capability_id': 'sales_pipeline_board', 'block_ids': ['dashboard', 'workflow', 'analytics', 'team'], 'gap': False}], 'agent_reviews': [{'capability_id': 'vehicle_inventory', 'block_ids': ['estate_registry', 'database', 'storage', 'capture'], 'verdict': 'mismatch', 'reason': 'estate_registry targets private property/estate assets, not vehicle inventory; the other blocks fit but this binding is strained.'}, {'capability_id': 'test_drive_bookings', 'block_ids': ['queue', 'workflow', 'notification'], 'verdict': 'endorse', 'reason': 'queue, workflow and notification plausibly support booking scheduling, execution and alerts.'}, {'capability_id': 'sales_pipeline_board', 'block_ids': ['dashboard', 'workflow', 'analytics', 'team'], 'verdict': 'endorse', 'reason': 'dashboard, workflow, analytics and team permissions naturally support a sales pipeline board.'}], 'agent_model': 'kimi-k2.7-code'}
CAPABILITIES = [{'id': 'vehicle_inventory', 'entity': 'vehicle', 'source': 'coder LLM (kimi-k2.7-code)', 'http': {'create': 'POST /v1/vehicle_inventory', 'list': 'GET /v1/vehicle_inventory', 'get': 'GET /v1/vehicle_inventory/{id}'}}, {'id': 'test_drive_bookings', 'entity': 'test_drive_booking', 'source': 'coder LLM (kimi-k2.7-code)', 'http': {'create': 'POST /v1/test_drive_bookings', 'list': 'GET /v1/test_drive_bookings', 'get': 'GET /v1/test_drive_bookings/{id}'}}, {'id': 'sales_pipeline_board', 'entity': 'pipeline_deal', 'source': 'coder LLM (kimi-k2.7-code)', 'http': {'create': 'POST /v1/sales_pipeline_board', 'list': 'GET /v1/sales_pipeline_board', 'get': 'GET /v1/sales_pipeline_board/{id}'}}]
GATES = {'kernel': 'TESTER', 'title': 'Acceptance inspector', 'mandate': 'Write and run the code-phase suite against what the WRITER produced (imports, dispatch load, models, routes answer JSON, handle() returns a mapping) and bounce those failures for another writer pass. Store-backed execute-all is pilot coverage, not this gate. Consult the coding agent for extra domain cases; admit them only as mutations of spec-derived payloads. Never patch app/. Never run the suite over HTTP — GET /v1/gates describes coverage only.', 'agent': 'consult', 'runs_over_http': False, 'suite': [{'file': 'tests/test_smoke.py', 'covers': 'import, offline dispatch load, handle() returns a mapping', 'gated': True}, {'file': 'tests/test_smoke.py', 'covers': 'Store-backed handle() ok and nested error scan', 'marker': 'pilot', 'gated': False}, {'file': 'tests/test_models.py', 'covers': 'sqlite round-trip via store.save / store.get', 'gated': True}, {'file': 'tests/test_routes.py', 'covers': 'HTTP 200 JSON for /health, kernel jobs, and each capability POST', 'gated': True}, {'file': 'tests/test_routes.py', 'covers': 'Store-backed POST accepted (ok is not False) and persisted', 'marker': 'pilot', 'gated': False}, {'file': 'tests/agent_domain_cases.py', 'covers': 'optional coding-agent domain mutations of spec payloads', 'optional': True, 'gated': False}]}


def _read_workspace_json(relative: str) -> Optional[Dict[str, Any]]:
    path = Path(__file__).resolve().parents[1] / relative
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _job(kernel: str) -> Dict[str, Any]:
    for item in JOBS:
        if item['kernel'] == kernel:
            return dict(item)
    return {'kernel': kernel}


def inventory() -> Dict[str, Any]:
    payload = _job('CLONER')
    payload['lock'] = _read_workspace_json('blocks.lock.json') or {
        'schema': 'blocks.lock.v1',
        'blocks': {},
    }
    return payload


def provenance() -> Dict[str, Any]:
    payload = _job('STORE_MANAGER')
    payload['build'] = _read_workspace_json('docs/build_provenance.json') or {}
    lock = _read_workspace_json('blocks.lock.json') or {}
    payload['clones'] = lock.get('blocks') or {}
    payload['store_ops'] = []
    return payload
