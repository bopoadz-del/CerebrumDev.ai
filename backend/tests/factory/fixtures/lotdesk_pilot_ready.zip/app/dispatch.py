"""Local block dispatch. No network, no store, no callback.

The old generated platforms answered a capability by POSTing to the operator's
block store. This imports the block that was vendored into this repository at
build time and calls it in-process, which is what makes the platform runnable
offline and independent of the factory's uptime.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import Any, Dict

_VENDOR = Path(__file__).resolve().parents[1] / "vendor" / "blocks"
_CACHE: Dict[str, Any] = {}


class BlockNotVendored(RuntimeError):
    """Asked for a block this platform does not carry."""


def load_block(block_id: str):
    if block_id in _CACHE:
        return _CACHE[block_id]
    path = _VENDOR / block_id / "block.py"
    if not path.is_file():
        raise BlockNotVendored(
            f"{block_id} is not vendored in this platform (looked in {path})"
        )
    spec = importlib.util.spec_from_file_location(f"vendored_{block_id}", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _CACHE[block_id] = module
    return module


BLOCK_CONTRACTS: Dict[str, Any] = {'estate_registry': {'block_id': 'estate_registry', 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}]}, 'database': {'block_id': 'database', 'default_action': 'query', 'action_options': ['query', 'insert', 'update', 'delete', 'create_table', 'list_tables'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'backend', 'type': 'string', 'required': False}, {'name': 'connection_string', 'type': 'string', 'required': False}], 'runtime_error_contracts': ['Unknown action'], 'input_keys_read_by_block': ['action', 'backend', 'connection_string', 'params', 'schema', 'sql', 'table', 'values', 'where', 'where_params']}, 'storage': {'block_id': 'storage', 'default_action': 'store', 'action_options': ['store', 'retrieve', 'delete', 'exists', 'list'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'backend', 'type': 'string', 'required': False}, {'name': 'data_dir', 'type': 'string', 'required': False}], 'runtime_error_contracts': ['backend_not_supported', 'file_not_found'], 'input_keys_read_by_block': ['action', 'backend', 'content', 'data_dir', 'exists', 'file_id', 'filename', 'hit', 'metadata', 'prefix', 'value']}, 'capture': {'block_id': 'capture', 'declared_inputs': [{'name': 'input', 'type': 'file', 'required': False}, {'name': 'ocr_languages', 'type': 'string', 'required': False}, {'name': 'ocr_engine', 'type': 'string', 'required': False}, {'name': 'llm_provider', 'type': 'string', 'required': False}, {'name': 'ollama_base_url', 'type': 'string', 'required': False}, {'name': 'ollama_model', 'type': 'string', 'required': False}, {'name': 'deepseek_api_key', 'type': 'string', 'required': False}, {'name': 'openrouter_api_key', 'type': 'string', 'required': False}, {'name': 'deepseek_model', 'type': 'string', 'required': False}, {'name': 'openrouter_model', 'type': 'string', 'required': False}, {'name': 'anthropic_api_key', 'type': 'string', 'required': False}, {'name': 'anthropic_model', 'type': 'string', 'required': False}, {'name': 'vector_db_url', 'type': 'string', 'required': False}, {'name': 'store_captures', 'type': 'boolean', 'required': False}, {'name': 'capture_collection', 'type': 'string', 'required': False}], 'runtime_error_contracts': ['Anthropic API key not configured', 'DeepSeek API key not configured', 'No valid image provided', 'OpenRouter API key not configured', 'Search failed', 'Vector DB not configured', 'easyocr not installed', 'pytesseract not installed. Run: pip install pytesseract pillow'], 'input_keys_read_by_block': ['action', 'anthropic_api_key', 'anthropic_model', 'base64', 'bytes', 'capture_collection', 'capture_id', 'clean_text', 'collection', 'confidence', 'content', 'deepseek_api_key', 'deepseek_model', 'engine', 'entities', 'file_path', 'image', 'language', 'languages', 'llm_provider', 'max_chars', 'n_results', 'ocr_engine', 'ocr_languages', 'ollama_base_url', 'ollama_model', 'openrouter_api_key', 'openrouter_model', 'raw_text', 'results', 'source', 'status', 'store_captures', 'summary', 'tags', 'text', 'total_tokens', 'type', 'usage', 'user_id']}, 'queue': {'block_id': 'queue', 'default_action': 'enqueue', 'action_options': ['enqueue', 'dequeue', 'status', 'list'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'backend', 'type': 'string', 'required': False}, {'name': 'redis_url', 'type': 'string', 'required': False}, {'name': 'max_workers', 'type': 'number', 'required': False}], 'runtime_error_contracts': ['job_not_found'], 'input_keys_read_by_block': ['action', 'job_id', 'job_type', 'max_retries', 'payload', 'priority', 'queue', 'redis_url']}, 'workflow': {'block_id': 'workflow', 'default_action': 'run', 'action_options': ['run', 'schedule', 'unschedule', 'list', 'get', 'history', 'status', 'health'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'max_pipeline_steps', 'type': 'number', 'required': False}, {'name': 'enable_scheduler', 'type': 'boolean', 'required': False}, {'name': 'default_timeout', 'type': 'number', 'required': False}], 'input_required_fields': ['steps'], 'runtime_error_contracts': ['Block ', 'Chain validation failed — incompatible blocks', 'No block specified', 'No steps defined', 'Pipeline ', 'Schedule requires cron or interval_seconds', 'Scheduler disabled', 'pipeline_id required for scheduling'], 'input_keys_read_by_block': ['action', 'block', 'break_on_error', 'cron', 'default_timeout', 'enable_scheduler', 'id', 'input', 'interval_seconds', 'max_pipeline_steps', 'params', 'pipeline_id', 'properties', 'status', 'steps', 'stop_on_error', 'timeout', 'trigger']}, 'notification': {'block_id': 'notification', 'default_action': 'send', 'action_options': ['send', 'broadcast', 'health'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'sendgrid_api_key', 'type': 'string', 'required': False}, {'name': 'smtp_host', 'type': 'string', 'required': False}, {'name': 'smtp_port', 'type': 'number', 'required': False}, {'name': 'smtp_user', 'type': 'string', 'required': False}, {'name': 'smtp_pass', 'type': 'string', 'required': False}, {'name': 'slack_webhook_url', 'type': 'string', 'required': False}, {'name': 'default_from_email', 'type': 'string', 'required': False}], 'input_required_fields': ['channel', 'message'], 'runtime_error_contracts': ['Block ', 'SMTP not configured (set SMTP_HOST or SENDGRID_API_KEY)', 'Slack webhook URL not configured', 'aiosmtplib not installed. Run: pip install aiosmtplib', 'block or tool name required for MCP channel', 'to (email) required', 'url required (set '], 'input_keys_read_by_block': ['action', 'block', 'blocks', 'body', 'channel', 'channels', 'default_from_email', 'email', 'headers', 'html', 'input', 'message', 'method', 'params', 'payload', 'sendgrid_api_key', 'slack_webhook_url', 'smtp_host', 'smtp_pass', 'smtp_port', 'smtp_user', 'status', 'subject', 'text', 'to', 'tool', 'url', 'webhook_url']}, 'dashboard': {'block_id': 'dashboard', 'default_action': 'render', 'action_options': ['render', 'add_widget', 'remove_widget', 'update_widget', 'get_metrics', 'list_widgets', 'save_layout', 'get_layout', 'subscribe_stream', 'get_snapshot'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'default_layout', 'type': 'string', 'required': False}, {'name': 'refresh_interval', 'type': 'number', 'required': False}, {'name': 'max_widgets', 'type': 'number', 'required': False}, {'name': 'theme', 'type': 'string', 'required': False}], 'runtime_error_contracts': ['Maximum widgets reached', 'Widget not found'], 'input_keys_read_by_block': ['action', 'callback', 'config', 'data_source', 'default_layout', 'hit', 'layout', 'max_widgets', 'position', 'refresh_interval', 'theme', 'title', 'type', 'updates', 'user_id', 'value', 'widget_id', 'widgets']}, 'analytics': {'block_id': 'analytics', 'default_action': 'track_event', 'action_options': ['track_event', 'leaderboard', 'usage_report', 'predict_failure', 'cost_analysis', 'get_metrics', 'compare_providers'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'window_size', 'type': 'number', 'required': False}, {'name': 'prediction_threshold', 'type': 'number', 'required': False}, {'name': 'retention_hours', 'type': 'number', 'required': False}, {'name': 'aggregation_interval', 'type': 'number', 'required': False}, {'name': 'prediction_window', 'type': 'number', 'required': False}, {'name': 'cost_per_1k_requests', 'type': 'json', 'required': False}], 'runtime_error_contracts': ['metric and value required'], 'input_keys_read_by_block': ['action', 'aggregation_interval', 'cost_per_1k', 'cost_per_1k_requests', 'leaderboard', 'metric', 'name', 'period', 'prediction_window', 'provider', 'providers', 'reliability_score', 'retention_hours', 'since', 'tags', 'threshold', 'timestamp', 'value', 'window']}, 'team': {'block_id': 'team', 'default_action': 'create_team', 'action_options': ['create_team', 'delete_team', 'invite_member', 'accept_invitation', 'remove_member', 'set_role', 'get_team', 'list_teams', 'get_members', 'get_team_context', 'switch_team', 'check_permission'], 'declared_inputs': [{'name': 'input', 'type': 'json', 'required': False}, {'name': 'max_members_per_team', 'type': 'number', 'required': False}, {'name': 'max_teams_per_org', 'type': 'number', 'required': False}, {'name': 'default_role', 'type': 'string', 'required': False}, {'name': 'invitation_expiry_hours', 'type': 'number', 'required': False}, {'name': 'enable_sso', 'type': 'boolean', 'required': False}, {'name': 'require_2fa_for_admins', 'type': 'boolean', 'required': False}], 'runtime_error_contracts': ['Cannot change owner', 'Cannot remove team owner', 'Invalid or expired invitation', 'Invitation expired', 'Not a member of this team', 'Not a team member', 'Only team owner can delete team', 'Owner cannot leave team. Transfer ownership first.', 'Permission denied', 'Permission denied: cannot invite members', 'Target user is not a team member', 'Target user not found in team', 'Team access denied', 'Team member limit reached', 'Team not found', 'Team slug ', 'user_id and name required'], 'input_keys_read_by_block': ['action', 'email', 'name', 'permission', 'plan', 'role', 'slug', 'target_user_id', 'team_id', 'token', 'user_id']}}


def _default_block_field(block_id: str, field: str, payload: Dict[str, Any]):
    """Fill a Store-required input the caller never heard of.

    Live tasting-room handlers sent the domain dict straight through.
    Analytics then demanded ``metric``/``value``, event_bus demanded
    ``topic``, and the suite went red. Construct those fields here so a
    valid capability payload still reaches a validating block.

    Notification ``channel`` must be a Store-known value. ``in_process`` is
    not one — live TESTER answered ``Unknown channel: in_process``. ``mcp``
    is known; it requires ``block`` or ``tool`` (filled below), not a network
    hop.
    """
    if field == "channel":
        ch = str(payload.get(field) or "mcp").strip().lower()
        if ch in {
            "in_process", "in-process", "http", "webhook", "email", "smtp",
            "slack", "",
        }:
            return "mcp"
        return ch
    if field in payload and payload[field] not in (None, ""):
        return payload[field]
    wrapping = {
        "data",
        "record",
        "payload",
        "input",
        "document",
        "event",
        "item",
        "body_data",
        "result",
    }
    if field in wrapping:
        return payload
    if field == "steps":
        roster = [k for k in BLOCK_CONTRACTS if k not in {"workflow"}]
        target = "validation" if "validation" in roster else (
            roster[0] if roster else "database"
        )
        return [{
            "id": "ok",
            "block": target,
            "input": payload,
            "result": {"status": "ok", "ok": True},
        }]
    if field in ("items", "records"):
        return [payload]
    if field == "members":
        return []
    defaults = {
        "topic": f"{block_id}.event",
        "metric": block_id,
        "value": 1,
        "table": "records",
        "entity": "records",
        "collection": "records",
        "channel": "mcp",
        "message": "update",
        "body": "update",
        "content": "update",
        "text": "update",
        "recipient": "operator",
        "to": "operator",
        "user_id": "operator",
        "role": "member",
        "name": block_id,
        "formula": "1",
        "expression": "1",
        "expr": "1",
        "query": "SELECT 1",
        "id": 1,
        "block": "database",
        "tool": "database",
    }
    return defaults.get(field, payload.get(field))


_ALWAYS_FILL = {
    "event_bus": ("topic", "event", "payload"),
    "analytics": ("metric", "value"),
    "notification": ("channel", "message", "recipient", "name", "block", "tool"),
    "workflow": ("steps", "result", "name"),
    "team": ("name", "role", "members"),
    "database": ("query", "table", "data"),
}


def _ensure_offline_block_input(
    block_id: str, data: Dict[str, Any], original: Dict[str, Any]
) -> Dict[str, Any]:
    """Fill Store fields even when contract harvest missed them.

    Live TESTER after shipping Store blocks: event_bus raised ``topic required``
    because the harvested required-fields list was empty; notification MCP
    needed a block/tool name; ``in_process`` was rejected as unknown; team
    called ``.lower()`` on None; workflow KeyError'd ``result``.
    """
    for field in _ALWAYS_FILL.get(block_id, ()):
        if field not in data or data[field] in (None, ""):
            data[field] = _default_block_field(block_id, field, original)
    if block_id == "notification":
        channel = str(data.get("channel") or "mcp").strip().lower()
        if channel in {
            "in_process", "in-process", "http", "webhook", "email", "smtp",
            "slack", "",
        }:
            channel = "mcp"
        data["channel"] = channel
        if channel == "mcp":
            roster = [k for k in BLOCK_CONTRACTS if k not in {"notification", "workflow"}]
            target = (
                "validation" if "validation" in roster
                else "database" if "database" in roster
                else (roster[0] if roster else "database")
            )
            if not data.get("block"):
                data["block"] = target
            if not data.get("tool"):
                data["tool"] = data.get("block") or target
        data.setdefault("message", "notification")
        data.setdefault("recipient", "operator")
    if block_id == "event_bus" and not data.get("topic"):
        data["topic"] = "event_bus.event"
    if block_id == "team":
        if not data.get("name"):
            data["name"] = original.get("name") or "ops"
        if not isinstance(data.get("role"), str) or not data.get("role"):
            data["role"] = "member"
        for key, value in list(data.items()):
            if value is None:
                data[key] = key
    if block_id == "workflow":
        existing = data.get("result")
        if not isinstance(existing, dict):
            data["result"] = {"status": "ok", "ok": True, "value": existing}
        else:
            existing.setdefault("status", "ok")
            existing.setdefault("ok", True)
        if not isinstance(data.get("steps"), list) or not data.get("steps"):
            data["steps"] = _default_block_field(block_id, "steps", original)
    if block_id == "database":
        if not data.get("query"):
            data["query"] = "SELECT 1"
        if not isinstance(data.get("table"), str) or not data.get("table"):
            data["table"] = "records"
        data.setdefault("data", original)
    return data


def _adapt_input(block_id: str, payload: Any, action: str | None) -> Dict[str, Any]:
    original = dict(payload) if isinstance(payload, dict) else {"value": payload}
    data = dict(original)
    contract = BLOCK_CONTRACTS.get(block_id) or {}
    required = list(contract.get("input_required_fields") or [])
    for item in contract.get("declared_inputs") or []:
        name = item.get("name") if isinstance(item, dict) else None
        if name and item.get("required") and name not in required:
            required.append(name)
    for field in required:
        if field in ("action",):
            continue
        if field not in data or data[field] in (None, ""):
            data[field] = _default_block_field(block_id, field, original)
    return _ensure_offline_block_input(block_id, data, original)


def execute(
    block_id: str,
    payload: Dict[str, Any],
    action: str | None = None,
    params: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Run a vendored block locally and return its result envelope.

    Real Store blocks are action-dispatched: the domain data travels as
    ``input`` and the operation name as ``action`` (each block declares a
    default in its block.json). A call with no action reaches blocks that
    answer "Unknown action" -- pass the one the capability needs.
    """
    module = load_block(block_id)
    run = getattr(module, "run", None)
    if run is None:
        raise BlockNotVendored(f"{block_id} exposes no run() entry point")
    kwargs = dict(params or {})
    if action is not None:
        kwargs["action"] = action
    adapted = _adapt_input(block_id, payload, action)
    # A block-level failure comes back as data, not as an exception. The
    # Store's shim raises RuntimeError on an error envelope, which destroys
    # the diagnosis: a handler (and a failing test) sees "Input validation
    # failed" with no block name and no field list. Structural failures --
    # a block that is not vendored -- still raise above.
    try:
        return run(input=adapted, **kwargs)
    except BlockNotVendored:
        raise
    except Exception as exc:
        return {
            "status": "error",
            "block": block_id,
            "action": action,
            "error": f"{type(exc).__name__}: {exc}",
        }
