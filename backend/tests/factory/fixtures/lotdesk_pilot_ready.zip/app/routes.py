"""HTTP surface for the platform's kernels and capabilities.

Kernel routes publish each build role's job. Capability routes run
entirely in-process: the handler dispatches to a vendored block and
the result is persisted locally. No outbound call.
"""

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, HTTPException

from app import jobs, store

router = APIRouter()


@router.get("/jobs")
def list_jobs() -> Dict[str, Any]:
    """Roster of every kernel job description."""
    return {"jobs": jobs.JOBS}


@router.get("/catalog")
def catalog() -> Dict[str, Any]:
    """COLLECTOR — Binding surveyor."""
    return jobs.CATALOG


@router.get("/inventory")
def inventory() -> Dict[str, Any]:
    """CLONER — Block stocker. Pinned vendor lock, read live."""
    return jobs.inventory()


@router.get("/capabilities")
def capabilities() -> Dict[str, Any]:
    """WRITER — Platform manufacturer. Capability HTTP surface."""
    return {"items": jobs.CAPABILITIES}


@router.get("/gates")
def gates() -> Dict[str, Any]:
    """TESTER — Acceptance inspector. Coverage only; does not run tests."""
    return jobs.GATES


@router.get("/provenance")
def provenance() -> Dict[str, Any]:
    """STORE_MANAGER — Store registrar. Clone register and provenance."""
    return jobs.provenance()


# --- vehicle_inventory (coder LLM (kimi-k2.7-code)) ---
from app.actions import vehicle_inventory as _vehicle_inventory_action  # noqa: E402


def _vehicle_inventory_handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        result = _vehicle_inventory_action.handle(payload)
    except Exception as exc:  # Store/runtime refusal is not HTTP 500
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    if not isinstance(result, dict):
        return {"ok": False, "error": f"handle() returned {type(result).__name__}"}
    return result


@router.post("/vehicle_inventory")
def vehicle_inventory_create(payload: Dict[str, Any]) -> Dict[str, Any]:
    CAPABILITY_ID = "vehicle_inventory"
    handle = _vehicle_inventory_handle
    save = lambda record: store.save("vehicle", record)
    list_all = lambda: store.list_all("vehicle")
    if not isinstance(payload, dict):
        return {"ok": False, "error": "payload must be an object"}
    constraints = {'year': {'min': 1900, 'max': 2100}, 'mileage': {'min': 0, 'max': 10000000}, 'price': {'min': 0.0}, 'status': {'allowed_values': ['available', 'pending', 'sold', 'wholesale']}}
    for name, rules in constraints.items():
        if name not in payload:
            continue
        value = payload[name]
        allowed = rules.get("allowed_values")
        if allowed is not None and value not in allowed:
            return {"ok": False,
                    "error": name + " must be one of: " + ", ".join(allowed)}
        low, high = rules.get("min"), rules.get("max")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if low is not None and value < low:
            return {"ok": False, "error": name + " is below the minimum"}
        if high is not None and value > high:
            return {"ok": False, "error": name + " is above the maximum"}
    required = ("vin", "stock_number", "make", "model", "year", "mileage", "price", "status")
    allowed_status = {"available", "pending", "sold", "wholesale"}

    for field in required:
        if field not in payload:
            return {"ok": False, "error": f"missing field: {field}"}

    vin = payload["vin"]
    stock_number = payload["stock_number"]
    make = payload["make"]
    model = payload["model"]
    year = payload["year"]
    mileage = payload["mileage"]
    price = payload["price"]
    status = payload["status"]

    if not isinstance(vin, str):
        return {"ok": False, "error": "vin must be a string"}
    if not isinstance(stock_number, str):
        return {"ok": False, "error": "stock_number must be a string"}
    if not isinstance(make, str):
        return {"ok": False, "error": "make must be a string"}
    if not isinstance(model, str):
        return {"ok": False, "error": "model must be a string"}
    if not isinstance(year, int) or isinstance(year, bool) or year < 1900 or year > 2100:
        return {"ok": False, "error": "year must be an int between 1900 and 2100"}
    if not isinstance(mileage, int) or isinstance(mileage, bool) or mileage < 0 or mileage > 10000000:
        return {"ok": False, "error": "mileage must be an int between 0 and 10000000"}
    if not isinstance(price, (int, float)) or isinstance(price, bool) or price < 0.0:
        return {"ok": False, "error": "price must be a number >= 0.0"}
    if not isinstance(status, str) or status not in allowed_status:
        return {"ok": False, "error": "status must be one of available, pending, sold, wholesale"}

    try:
        result = handle(payload)
        saved = save(payload)
    except Exception as e:
        return {"ok": False, "error": str(e)}

    return {"ok": True, "record": saved, "capability": CAPABILITY_ID}


@router.get("/vehicle_inventory")
def vehicle_inventory_list() -> Dict[str, Any]:
    return {"items": store.list_all("vehicle")}


@router.get("/vehicle_inventory/{item_id}")
def vehicle_inventory_get(item_id: int) -> Dict[str, Any]:
    record = store.get("vehicle", item_id)
    if record is None:
        raise HTTPException(status_code=404, detail="not found")
    return record


# --- test_drive_bookings (coder LLM (kimi-k2.7-code)) ---
from app.actions import test_drive_bookings as _test_drive_bookings_action  # noqa: E402


def _test_drive_bookings_handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        result = _test_drive_bookings_action.handle(payload)
    except Exception as exc:  # Store/runtime refusal is not HTTP 500
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    if not isinstance(result, dict):
        return {"ok": False, "error": f"handle() returned {type(result).__name__}"}
    return result


@router.post("/test_drive_bookings")
def test_drive_bookings_create(payload: Dict[str, Any]) -> Dict[str, Any]:
    CAPABILITY_ID = "test_drive_bookings"
    handle = _test_drive_bookings_handle
    save = lambda record: store.save("test_drive_booking", record)
    list_all = lambda: store.list_all("test_drive_booking")
    if not isinstance(payload, dict):
        return {"ok": False, "error": "payload must be an object"}
    constraints = {'status': {'allowed_values': ['requested', 'confirmed', 'completed', 'cancelled', 'no_show']}, 'source': {'allowed_values': ['customer', 'dealer']}}
    for name, rules in constraints.items():
        if name not in payload:
            continue
        value = payload[name]
        allowed = rules.get("allowed_values")
        if allowed is not None and value not in allowed:
            return {"ok": False,
                    "error": name + " must be one of: " + ", ".join(allowed)}
        low, high = rules.get("min"), rules.get("max")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if low is not None and value < low:
            return {"ok": False, "error": name + " is below the minimum"}
        if high is not None and value > high:
            return {"ok": False, "error": name + " is above the maximum"}
    if not isinstance(payload, dict):
        return {"ok": False, "error": "payload must be a dict"}

    required = ["vehicle_id", "customer_id", "scheduled_date", "status", "source"]
    allowed_status = {"requested", "confirmed", "completed", "cancelled", "no_show"}
    allowed_source = {"customer", "dealer"}
    optional_str = ["salesperson_id", "notes"]

    for field in required:
        if field not in payload:
            return {"ok": False, "error": f"missing required field: {field}"}
        if not isinstance(payload[field], str):
            return {"ok": False, "error": f"{field} must be a string"}

    if payload["status"] not in allowed_status:
        return {"ok": False, "error": "status must be one of requested, confirmed, completed, cancelled, no_show"}

    if payload["source"] not in allowed_source:
        return {"ok": False, "error": "source must be one of customer, dealer"}

    for field in optional_str:
        if field in payload and not isinstance(payload[field], str):
            return {"ok": False, "error": f"{field} must be a string"}

    try:
        record = handle(payload)
        saved = save(payload)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

    return {"ok": True, "capability": CAPABILITY_ID, "id": saved.get("id"), "record": saved}


@router.get("/test_drive_bookings")
def test_drive_bookings_list() -> Dict[str, Any]:
    return {"items": store.list_all("test_drive_booking")}


@router.get("/test_drive_bookings/{item_id}")
def test_drive_bookings_get(item_id: int) -> Dict[str, Any]:
    record = store.get("test_drive_booking", item_id)
    if record is None:
        raise HTTPException(status_code=404, detail="not found")
    return record


# --- sales_pipeline_board (coder LLM (kimi-k2.7-code)) ---
from app.actions import sales_pipeline_board as _sales_pipeline_board_action  # noqa: E402


def _sales_pipeline_board_handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        result = _sales_pipeline_board_action.handle(payload)
    except Exception as exc:  # Store/runtime refusal is not HTTP 500
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    if not isinstance(result, dict):
        return {"ok": False, "error": f"handle() returned {type(result).__name__}"}
    return result


@router.post("/sales_pipeline_board")
def sales_pipeline_board_create(payload: Dict[str, Any]) -> Dict[str, Any]:
    CAPABILITY_ID = "sales_pipeline_board"
    handle = _sales_pipeline_board_handle
    save = lambda record: store.save("pipeline_deal", record)
    list_all = lambda: store.list_all("pipeline_deal")
    if not isinstance(payload, dict):
        return {"ok": False, "error": "payload must be an object"}
    constraints = {'stage': {'allowed_values': ['new', 'contacted', 'test_drive', 'offer', 'sold', 'lost']}, 'sale_price': {'min': 0}, 'probability': {'min': 0, 'max': 100}}
    for name, rules in constraints.items():
        if name not in payload:
            continue
        value = payload[name]
        allowed = rules.get("allowed_values")
        if allowed is not None and value not in allowed:
            return {"ok": False,
                    "error": name + " must be one of: " + ", ".join(allowed)}
        low, high = rules.get("min"), rules.get("max")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        if low is not None and value < low:
            return {"ok": False, "error": name + " is below the minimum"}
        if high is not None and value > high:
            return {"ok": False, "error": name + " is above the maximum"}
    required = ["vehicle_vin", "customer_id", "stage", "sale_price", "assigned_salesperson", "probability"]
    for field in required:
        if field not in payload:
            return {"ok": False, "error": f"missing field: {field}"}

    if not isinstance(payload["vehicle_vin"], str):
        return {"ok": False, "error": "vehicle_vin must be a string"}
    if not isinstance(payload["customer_id"], str):
        return {"ok": False, "error": "customer_id must be a string"}
    if payload["stage"] not in ("new", "contacted", "test_drive", "offer", "sold", "lost"):
        return {"ok": False, "error": "stage must be one of new, contacted, test_drive, offer, sold, lost"}
    if not isinstance(payload["sale_price"], int) or payload["sale_price"] < 0:
        return {"ok": False, "error": "sale_price must be an int >= 0"}
    if not isinstance(payload["assigned_salesperson"], str):
        return {"ok": False, "error": "assigned_salesperson must be a string"}
    if not isinstance(payload["probability"], int) or payload["probability"] < 0 or payload["probability"] > 100:
        return {"ok": False, "error": "probability must be an int between 0 and 100"}
    if "notes" in payload and not isinstance(payload["notes"], str):
        return {"ok": False, "error": "notes must be a string"}

    try:
        record = handle(payload)
        stored = save(payload)
        return {"ok": True, "capability": CAPABILITY_ID, "record": stored}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


@router.get("/sales_pipeline_board")
def sales_pipeline_board_list() -> Dict[str, Any]:
    return {"items": store.list_all("pipeline_deal")}


@router.get("/sales_pipeline_board/{item_id}")
def sales_pipeline_board_get(item_id: int) -> Dict[str, Any]:
    record = store.get("pipeline_deal", item_id)
    if record is None:
        raise HTTPException(status_code=404, detail="not found")
    return record

