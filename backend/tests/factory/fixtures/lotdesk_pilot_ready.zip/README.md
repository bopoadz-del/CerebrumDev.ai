# LotDesk

LotDesk is a self-contained business platform for automotive dealerships. It helps teams manage inventory, schedule test drives, and track deals through a sales pipeline — all without relying on external services.

## Capabilities

- **Vehicle inventory** – manage makes, models, pricing, and availability.
- **Test drive bookings** – schedule, reschedule, and track customer test drives.
- **Sales pipeline board** – move deals through stages from lead to close.

## Vendored blocks

LotDesk ships with its building blocks vendored under `vendor/blocks/` so it runs fully offline and never calls back to an app store or external registry.

Included blocks:

- `analytics`
- `capture`
- `dashboard`
- `database`
- `estate_registry`
- `notification`
- `queue`
- `storage`
- `team`
- `workflow`

## Running locally

```bash
pip install -r requirements.txt
uvicorn app.main:app
```

Once running, check the service with:

- `GET /health` – service health status
- `GET /v1/jobs` – kernel job queue overview

<!-- kernel-jobs section is appended below -->

## Kernel jobs and HTTP

`GET /v1/jobs` lists every kernel's job description. Distinctive surfaces:

| Kernel | Job | Agent | Routes |
|---|---|---|---|
| `COLLECTOR` | Binding surveyor | consult | `GET /v1/catalog` |
| `CLONER` | Block stocker | none | `GET /v1/inventory` |
| `WRITER` | Platform manufacturer | manufacture | `GET /v1/capabilities`, `POST /v1/{capability}`, `GET /v1/{capability}`, `GET /v1/{capability}/{id}` |
| `TESTER` | Acceptance inspector | consult | `GET /v1/gates` |
| `STORE_MANAGER` | Store registrar | none | `GET /v1/provenance` |

These routes inspect the manufactured platform. They do not re-run the factory
and they do not execute the test suite (`GET /v1/gates` describes coverage only).
